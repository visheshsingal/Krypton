KRYPTON AI SECURITY - WINDOWS INSTALLER

Version: 1.0.0 (64-bit)
Supported OS: Windows 10 and Windows 11

INSTALL
1. Extract this ZIP to a folder on your PC.
2. Run Krypton-Security-Setup-1.0.0.exe.
3. Follow the setup wizard. Krypton installs for your Windows user and does not require administrator access.
4. Launch Krypton from the Start menu or desktop shortcut and activate with your company credentials.

UNINSTALL
Open Settings > Apps > Installed apps, select Krypton AI Security, and choose Uninstall.
The uninstaller is created and registered by the setup wizard.

SECURITY
Krypton does not disable Windows Security, SmartScreen, or other system protections.
Windows may show a publisher warning until the installer is signed with a trusted code-signing certificate.
Verify the installer SHA-256 using SHA256SUMS.txt before running it.

SCOPE
Prompt scanning is performed in supported Krypton-managed Chrome/Edge profiles only.
See the Krypton website for current product scope and privacy information.
